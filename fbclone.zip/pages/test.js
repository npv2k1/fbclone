import Head from "next/head"

function test() {
    return (
      <div>
        {/* <Head>
          <link rel="stylesheet" href="/assets/css/all.min.css" />
        </Head> */}
        
       hello <i className="fas fa-address-card"></i>
      </div>
    );
}

export default test
